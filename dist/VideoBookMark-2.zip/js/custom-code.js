/* 
    This is provided to override any existing functions in wrapper.js, page.js and 
    quiz.js before initializing the course.
    Or just making any customize code for certain course.

    This is to maintain wrapper.js, page.js and 
    quiz.js what they are and using this js file if there
    is a certain course that has difference from the others.
 */
/* 
    vb_BookmarkTime: string (json - {"[video-name: string]": 0:number})
    vb_JumpToBookmarkSlide: boolean
    vb_PasswordNumber: number
    vb_PasswordPhrases: string
    vb_Passwords: string
    vb_SendCompletion: number
    vb_ShowPassword: boolean
    vb_ShowVideoIntro: boolean
    vb_ThisVideoHasBeenSeen: boolean
    vb_VideoFail: boolean
    vb_VideoName: string
    vb_VideoReady: boolean
*/

// UI for page1.html
slideDown('#page-title-1-wrap', 2);
fadeIn('#company-logo-bottom', 4, 0.3);
fadeIn('#last-updated-wrap', 4, 0.3);

// UI for page2.html
// slideDown('#page-title-2-wrap', 2);

// UI for place-saved.html
// slideDown('#page-title-2-wrap', 2);